// EduLabs AI - Real Three.js Science Lab GLB viewer
let science3D = {};
window.initScienceViewer = function(){
 const el=document.getElementById('science-3d-viewer');
 if(!el || !window.THREE) return;
 const scene=new THREE.Scene();
 const camera=new THREE.PerspectiveCamera(45, el.clientWidth/el.clientHeight,.1,1000);
 camera.position.set(0,1,3);
 const renderer=new THREE.WebGLRenderer({antialias:true});
 renderer.setSize(el.clientWidth,el.clientHeight);
 el.innerHTML='';
 el.appendChild(renderer.domElement);
 const controls=new THREE.OrbitControls(camera,renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xffffff,0x444444,2));
 function loop(){requestAnimationFrame(loop);controls.update();renderer.render(scene,camera);}
 loop();
 science3D={scene,camera,renderer,controls};
};
window.loadScienceGLB=function(url){
 if(!science3D.scene) initScienceViewer();
 if(!THREE.GLTFLoader) return;
 new THREE.GLTFLoader().load(url,g=>{
   science3D.scene.children.filter(x=>x.userData.generated).forEach(x=>science3D.scene.remove(x));
   g.scene.userData.generated=true;
   science3D.scene.add(g.scene);
 });
};
window.addEventListener('load',initScienceViewer);
