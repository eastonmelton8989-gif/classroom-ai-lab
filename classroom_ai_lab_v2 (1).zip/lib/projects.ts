import {Project} from "./types";
const store=new Map<string,Project>();
export function saveProject(p:Project){store.set(p.id,p);return p}
export function getProject(id:string){return store.get(id)}