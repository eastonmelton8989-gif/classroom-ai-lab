// EduLabs AI Gateway
// Routes requests between hosted AI mode and optional school/local mode.
export async function routeAI(request) {
  const mode = process.env.EDULABS_AI_MODE || "cloud";
  return { mode, message: "AI gateway ready" };
}
