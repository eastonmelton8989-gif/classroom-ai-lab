'use client';

import {useEffect, useRef} from 'react';
import {Engine, Scene, ArcRotateCamera, HemisphericLight, MeshBuilder, Vector3, Color4} from '@babylonjs/core';

export default function Science3DViewer({analysis}:{analysis?:string}){
  const canvasRef=useRef<HTMLCanvasElement|null>(null);

  useEffect(()=>{
    if(!canvasRef.current) return;
    const engine=new Engine(canvasRef.current,true);
    const scene=new Scene(engine);
    scene.clearColor=new Color4(0.03,0.05,0.1,1);

    const camera=new ArcRotateCamera("camera",Math.PI/2,Math.PI/3,8,Vector3.Zero(),scene);
    camera.attachControl(canvasRef.current,true);
    new HemisphericLight("light",new Vector3(0,1,0),scene);

    // Starter procedural 3D science scene.
    // AI scene JSON can replace these primitives later.
    MeshBuilder.CreateSphere("core",{diameter:2},scene);
    MeshBuilder.CreateTorus("orbit",{diameter:4,thickness:.03},scene);

    engine.runRenderLoop(()=>scene.render());
    const resize=()=>engine.resize();
    window.addEventListener("resize",resize);
    return ()=>{window.removeEventListener("resize",resize);engine.dispose();}
  },[]);

  return <canvas ref={canvasRef} style={{width:'100%',height:500}} aria-label="Interactive 3D science viewer"/>;
}
