import {NextRequest,NextResponse} from "next/server";
import {Analysis} from "../../../lib/types";

const fallback=(description:string):Analysis=>({
 title:"Interactive science model",
 summary:description||"A conceptual 3D classroom visualization of the uploaded scientific diagram.",
 objects:["nucleus","protons","neutrons","electron shells"],
 animation:["Introduce the diagram","Highlight the nucleus","Identify the particles","Animate the interaction","Show the final state"],
 mode: /fission/i.test(description)?"fission":/fusion/i.test(description)?"fusion":/alpha/i.test(description)?"alpha":/beta/i.test(description)?"beta":/gamma/i.test(description)?"gamma":"atom",
 source:"demo"
});

export async function POST(req:NextRequest){
 const form=await req.formData();
 const description=String(form.get("description")||"");
 const file=form.get("image") as File|null;
 const base=fallback(description);
 if(!process.env.GOOGLE_API_KEY || !file) return NextResponse.json(base);
 try{
  const {GoogleGenerativeAI}=await import("@google/generative-ai");
  const ai=new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
  const model=ai.getGenerativeModel({model:"gemini-2.0-flash"});
  const data=Buffer.from(await file.arrayBuffer()).toString("base64");
  const prompt=`Analyze this science classroom diagram. Return ONLY valid JSON with keys title, summary, objects, animation, mode. mode must be one of atom, alpha, beta, gamma, fission, fusion. Do not invent uncertain labels. Context: ${description}`;
  const out=await model.generateContent([{text:prompt},{inlineData:{mimeType:file.type,data}}]);
  const parsed=JSON.parse(out.response.text().replace(/```json|```/g,"").trim());
  return NextResponse.json({...base,...parsed,source:"ai"});
 }catch{return NextResponse.json({...base,source:"fallback"})}
}