# EduLabs AI

Public-ready Next.js/Vercel prototype for the school project.

## What is included
- Video Lab: paste/drag YouTube URLs, supported embed preview, shareable URL.
- 3D Science Lab: image upload, AI diagram analysis, Sora 2 video generation, polling, and video playback.
- Server-only `OPENAI_API_KEY` integration.

## Deploy
1. Push this folder to GitHub.
2. Import the repo into Vercel as a Next.js project.
3. In Vercel Project Settings → Environment Variables, add `OPENAI_API_KEY` for Production/Preview as needed.
4. Redeploy after adding the key.

Vercel supports Next.js directly and environment variables are the correct place for server secrets. Never use `NEXT_PUBLIC_OPENAI_API_KEY`.

## AI video
The Science Lab uses the OpenAI Videos API with `sora-2`, 12 seconds, landscape 1280x720, and the uploaded diagram as an input reference. Generation is asynchronous: the site starts a job, polls its status, and then streams the completed MP4 through a server route.
