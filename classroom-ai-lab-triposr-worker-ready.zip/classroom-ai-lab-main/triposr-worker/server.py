from flask import Flask, request, jsonify, send_from_directory
import os, uuid, subprocess

app = Flask(__name__)
UPLOADS='uploads'
OUTPUTS='outputs'
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(OUTPUTS, exist_ok=True)

@app.route('/models/<path:name>')
def models(name):
    return send_from_directory(OUTPUTS, name)

@app.post('/generate')
def generate():
    image=request.files.get('image')
    if not image:
        return jsonify({'error':'missing image'}),400
    job=str(uuid.uuid4())
    src=f'{UPLOADS}/{job}.png'
    out=f'{OUTPUTS}/{job}.glb'
    image.save(src)

    # Replace this command with your TripoSR inference command.
    # Example placeholder:
    # subprocess.run(['python','run.py','--image',src,'--output',out],check=True)
    return jsonify({'status':'worker_ready','modelUrl':f'/models/{job}.glb'})

if __name__=='__main__':
    app.run(host='0.0.0.0',port=8000)
