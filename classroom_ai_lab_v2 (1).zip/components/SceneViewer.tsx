 "use client";
import {useEffect,useRef} from "react"; import * as THREE from "three"; import {SceneMode} from "../lib/types";
export default function SceneViewer({mode}:{mode:SceneMode}){
 const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{const el=ref.current;if(!el)return;
  const scene=new THREE.Scene();scene.background=new THREE.Color(0x07101d);
  const cam=new THREE.PerspectiveCamera(48,el.clientWidth/el.clientHeight,.1,100);cam.position.set(0,2.2,8);
  const ren=new THREE.WebGLRenderer({antialias:true});ren.setPixelRatio(Math.min(devicePixelRatio,2));ren.setSize(el.clientWidth,el.clientHeight);el.appendChild(ren.domElement);
  scene.add(new THREE.AmbientLight(0xffffff,1.7));const light=new THREE.PointLight(0xffffff,28);light.position.set(3,4,5);scene.add(light);
  const nucleus=new THREE.Group(), colors=[0xef4444,0x64748b];for(let i=0;i<12;i++){const s=new THREE.Mesh(new THREE.SphereGeometry(.32,22,22),new THREE.MeshStandardMaterial({color:colors[i%2]}));const a=i*2.399;s.position.set(Math.cos(a)*.62,Math.sin(a)*.62,(i%3-.8)*.3);nucleus.add(s)}scene.add(nucleus);
  const electrons:any[]=[];for(let i=0;i<3;i++){const r=1.55+i*.62;const ring=new THREE.Mesh(new THREE.TorusGeometry(r,.018,8,100),new THREE.MeshBasicMaterial({color:0x94a3b8,transparent:true,opacity:.55}));ring.rotation.x=Math.PI/2;ring.rotation.z=i*.6;scene.add(ring);const e=new THREE.Mesh(new THREE.SphereGeometry(.1,16,16),new THREE.MeshStandardMaterial({color:0x38bdf8,emissive:0x073b5c}));scene.add(e);electrons.push({r,e,i})}
  const clock=new THREE.Clock();let raf=0;const loop=()=>{const t=clock.getElapsedTime();nucleus.rotation.y=t*.25;
   electrons.forEach((x:any)=>{const a=t*(.7+x.i*.25);x.e.position.set(Math.cos(a)*x.r,Math.sin(a)*x.r*.35,Math.sin(a)*x.r)});
   if(mode==="fission"){nucleus.scale.x=1+Math.sin(t*2)*.12;nucleus.position.x=Math.sin(t)*.35}
   if(mode==="fusion"){nucleus.position.x=Math.sin(t*2)*.12;nucleus.scale.setScalar(1+Math.sin(t*2)*.07)}
   if(mode==="alpha"){nucleus.position.x=Math.sin(t)*.15}
   if(mode==="beta"){electrons[0].e.position.y+=Math.sin(t*4)*.002}
   if(mode==="gamma"){nucleus.rotation.z=Math.sin(t*3)*.08}
   ren.render(scene,cam);raf=requestAnimationFrame(loop)};loop();
  const resize=()=>{cam.aspect=el.clientWidth/el.clientHeight;cam.updateProjectionMatrix();ren.setSize(el.clientWidth,el.clientHeight)};addEventListener("resize",resize);
  return()=>{cancelAnimationFrame(raf);removeEventListener("resize",resize);ren.dispose();el.innerHTML=""}
 },[mode]);return <div className="viewer" ref={ref}/>
}