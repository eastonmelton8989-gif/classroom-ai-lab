export type SceneMode="atom"|"alpha"|"beta"|"gamma"|"fission"|"fusion";
export type Analysis={title:string;summary:string;objects:string[];animation:string[];mode:SceneMode;source:string};
export type Project={id:string;title:string;description:string;mode:SceneMode;analysis:Analysis;createdAt:string};