# AI Octopus Helper 🐙

Assistant layer for explanations, questions, quizzes, and lesson improvements.
