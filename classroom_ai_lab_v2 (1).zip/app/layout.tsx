import "./globals.css";
export const metadata={title:"Classroom AI Lab",description:"Interactive AI science classroom tools"};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}