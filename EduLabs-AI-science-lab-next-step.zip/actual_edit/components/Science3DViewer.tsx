'use client';
import {useEffect,useRef} from 'react';

export default function Science3DViewer({analysis,topic}:{analysis?:string;topic?:string}){
 const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  let renderer:any,scene:any,camera:any,frame:number;
  let mounted=true;
  (async()=>{
   const THREE=await import('three');
   if(!mounted||!ref.current)return;
   scene=new THREE.Scene();
   camera=new THREE.PerspectiveCamera(45,500/350,0.1,100);
   camera.position.z=4;
   renderer=new THREE.WebGLRenderer({antialias:true});
   renderer.setSize(500,350);
   ref.current.innerHTML='';
   ref.current.appendChild(renderer.domElement);
   scene.add(new THREE.AmbientLight(0xffffff,1));
   const light=new THREE.DirectionalLight(0xffffff,2); light.position.set(2,3,4); scene.add(light);
   const group=new THREE.Group();
   const core=new THREE.Mesh(new THREE.SphereGeometry(0.7,48,48),new THREE.MeshStandardMaterial({wireframe:true}));
   group.add(core);
   const ring=new THREE.Mesh(new THREE.TorusGeometry(1.2,0.03,16,100),new THREE.MeshBasicMaterial());
   group.add(ring);
   scene.add(group);
   const animate=()=>{group.rotation.y+=0.01;renderer.render(scene,camera);frame=requestAnimationFrame(animate)};
   animate();
  })();
  return()=>{mounted=false;cancelAnimationFrame(frame);renderer?.dispose?.()}
 },[analysis,topic]);
 return <div className="analysis"><h3>AI 3D Science Preview</h3><div ref={ref}/><small>{topic||'Science topic'} scene generated from analysis.</small></div>
}
