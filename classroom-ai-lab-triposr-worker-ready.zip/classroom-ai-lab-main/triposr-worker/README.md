# EduLabs AI TripoSR Worker

Runs on your own PC and provides the `/generate` endpoint used by the Science Lab.

Install:

```
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
python server.py
```

Then point your Vercel API to this worker with:

`TRIPOSR_ENDPOINT=http://YOUR-PC-IP:8000/generate`

Add the real TripoSR inference command in `server.py`.
