export default async function Watch({params}:{params:Promise<{id:string}>}){
 const {id}=await params;
 return <main className="watch"><a href="/">← Classroom AI Lab</a><h1>Shared Classroom Video</h1><div className="video big"><iframe src={`https://www.youtube.com/embed/${encodeURIComponent(id)}`} title="Shared classroom video" allowFullScreen/></div><p>Playback uses the video's supported embedded-player permissions. Network restrictions are not bypassed.</p></main>
}