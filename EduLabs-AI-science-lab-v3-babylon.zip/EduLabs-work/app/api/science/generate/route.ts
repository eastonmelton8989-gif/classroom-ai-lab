import {NextResponse} from 'next/server';
export const runtime='nodejs';
export async function POST(req:Request){try{const key=process.env.OPENAI_API_KEY;if(!key)return NextResponse.json({error:'OPENAI_API_KEY is not configured on the server.'},{status:500});const form=await req.formData();const image=form.get('image');const topic=String(form.get('topic')||'');const analysis=String(form.get('analysis')||'');const requestedSeconds=Number(form.get('seconds')||30);const seconds=Math.min(Math.max(Number.isFinite(requestedSeconds)?requestedSeconds:30,20),60);if(!(image instanceof File))return NextResponse.json({error:'No diagram uploaded.'},{status:400});const prompt=`Create a classroom-safe educational 3D-style science animation from this diagram.
Topic: ${topic||'the scientific concept shown in the diagram'}.
Analysis: ${analysis||'Analyze the supplied diagram yourself.'}.

Create a teacher-quality visual lesson:
- transform the flat diagram into a dimensional 3D visualization
- show important structures as layered objects
- use smooth camera movement, zooms, and rotations
- highlight labels and explain relationships
- show processes over time when appropriate
- keep all science accurate for students
Do not replace the diagram with a generic scene. The uploaded diagram is the source of truth.`;const fd=new FormData();fd.append('model','sora-2');fd.append('prompt',prompt);fd.append('seconds',String(seconds));fd.append('size','1280x720');fd.append('input_reference',image,image.name||'diagram.png');const r=await fetch('https://api.openai.com/v1/videos',{method:'POST',headers:{Authorization:`Bearer ${key}`},body:fd});const d=await r.json();if(!r.ok)return NextResponse.json({error:d?.error?.message||'Video generation failed.'},{status:r.status});return NextResponse.json({id:d.id,status:d.status,progress:d.progress||0,prompt});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Unexpected error.'},{status:500})}}
