import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'EduLabs AI — Classroom Science Tools',description:'AI-powered educational video and science visualization tools.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <>{children}</>}
