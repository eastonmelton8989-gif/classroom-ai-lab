import {NextResponse} from "next/server";
import {getProject} from "../../../../lib/projects";
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){
 const {id}=await params; const p=getProject(id);
 return p?NextResponse.json(p):NextResponse.json({error:"Project not found"},{status:404});
}