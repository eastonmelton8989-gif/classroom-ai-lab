# EduLabs School Mode

Optional private deployment mode. A school can run an internal AI server and point the gateway to it.

No student installation is required for normal website users.
