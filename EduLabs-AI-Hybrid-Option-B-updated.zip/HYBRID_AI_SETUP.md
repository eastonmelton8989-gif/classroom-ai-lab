# EduLabs AI Hybrid Architecture

Default: students use the website without installing software.

Optional: schools can connect a private AI server.

Pipeline:
image -> analysis -> 3D -> lesson -> Octopus Helper
