import {NextRequest,NextResponse} from "next/server";
import {saveProject} from "../../../lib/projects";
export async function POST(req:NextRequest){
 const body=await req.json();
 const p={...body,id:crypto.randomUUID(),createdAt:new Date().toISOString()};
 return NextResponse.json(saveProject(p));
}