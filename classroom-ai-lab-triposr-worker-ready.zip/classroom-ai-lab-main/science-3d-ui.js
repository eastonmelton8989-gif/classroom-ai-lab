// Connect Generate Real 3D Model button
const gen3d=document.getElementById('generate3d');
if(gen3d){
 gen3d.onclick=async()=>{
  const file=document.getElementById('file').files[0];
  const status=document.getElementById('status');
  if(!file){status.textContent='Upload a diagram first.';return;}
  status.textContent='Generating AI 3D model...';
  const form=new FormData(); form.append('image',file);
  try{
   const r=await fetch('/api/generate-3d',{method:'POST',body:form});
   const d=await r.json();
   if(!d.modelUrl) throw new Error(d.error||'No model returned');
   window.loadScienceGLB(d.modelUrl);
   const a=document.getElementById('download3d'); a.href=d.modelUrl; a.hidden=false;
   status.textContent='3D model ready.';
  }catch(e){status.textContent='3D generation: '+e.message;}
 };
}
