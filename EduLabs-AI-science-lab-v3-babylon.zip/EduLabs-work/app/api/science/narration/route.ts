import {NextResponse} from 'next/server';

export const runtime='nodejs';

export async function POST(req:Request){
 try{
  const key=process.env.OPENAI_API_KEY;
  if(!key)return NextResponse.json({error:'OPENAI_API_KEY is not configured.'},{status:500});
  const {analysis,topic}=await req.json();
  const r=await fetch('https://api.openai.com/v1/responses',{
   method:'POST',
   headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},
   body:JSON.stringify({
    model:'gpt-5',
    input:`Write a clear classroom narration script for a science animation. Topic: ${topic||'science'}. Diagram analysis: ${analysis||''}. Keep it educational and concise.`
   })
  });
  const d=await r.json();
  return NextResponse.json({script:d.output_text||''});
 }catch(e){return NextResponse.json({error:String(e)},{status:500})}
}
