// EduLabs AI Science Lab — 3D generation controller
let generatedModelUrl = null;

const threeButton = document.getElementById('generate3d');
const downloadButton = document.getElementById('download3d');
const status = document.getElementById('status');
const fileInput = document.getElementById('file');
const subjectInput = document.getElementById('subject');
const topicInput = document.getElementById('topic');
const threeStatus = document.getElementById('threeStatus');
const modelProgress = document.getElementById('modelProgress');
const progressBar = document.getElementById('progressBar');
const progressPercent = document.getElementById('progressPercent');
const progressTitle = document.getElementById('progressTitle');
const progressDetail = document.getElementById('progressDetail');

function setStep(step) {
  if (!threeStatus) return;
  const order = ['prepare', 'generate', 'fix', 'ready'];
  const index = order.indexOf(step);
  threeStatus.querySelectorAll('[data-step]').forEach(el => {
    const i = order.indexOf(el.dataset.step);
    el.classList.toggle('active', i === index);
    el.classList.toggle('done', i < index || step === 'ready' && i < order.length - 1);
  });
}

function setProgress(percent, title, detail, busy = true) {
  if (!modelProgress) return;
  modelProgress.classList.add('visible');
  if (progressBar) {
    progressBar.style.width = `${Math.max(0, Math.min(100, percent))}%`;
    progressBar.classList.toggle('busy', busy && percent < 100);
  }
  if (progressPercent) progressPercent.textContent = `${Math.round(percent)}%`;
  if (progressTitle) progressTitle.textContent = title;
  if (progressDetail) progressDetail.textContent = detail;
}

function hideProgress() {
  modelProgress?.classList.remove('visible');
  progressBar?.classList.remove('busy');
}

function friendlyError(error) {
  const message = String(error?.message || error || 'Unknown error');
  if (/worker|endpoint|unavailable|503|502/i.test(message)) {
    return 'The 3D service is not connected right now. The image is still safe and unchanged. Please try again later.';
  }
  if (/model|glb|loader|format/i.test(message)) {
    return 'The 3D model could not be prepared from this image. Try a clear image with one main object.';
  }
  return 'We could not create the 3D model from that image. Try a clearer image with one main object.';
}

async function generateReal3D() {
  const file = fileInput?.files?.[0];
  if (!file) {
    status.textContent = 'Choose a science image first.';
    setStep('prepare');
    hideProgress();
    return;
  }

  if (!file.type.startsWith('image/')) {
    status.textContent = 'Please choose an image file.';
    hideProgress();
    return;
  }

  threeButton.disabled = true;
  threeButton.classList.add('generate-busy');
  const originalButtonText = threeButton.dataset.originalText || threeButton.textContent;
  threeButton.dataset.originalText = originalButtonText;
  threeButton.textContent = 'Creating 3D Model…';
  if (downloadButton) downloadButton.hidden = true;

  setStep('prepare');
  setProgress(8, 'Preparing image…', 'Checking your image and sending it to the 3D generator.');
  status.textContent = 'Preparing your science image…';

  try {
    const data = new FormData();
    data.append('image', file, file.name);
    data.append('subject', subjectInput?.value || 'general');
    data.append('topic', topicInput?.value?.trim() || '');

    setStep('generate');
    setProgress(25, 'Creating your 3D model…', 'AI reconstruction is running. This may take a little while.');
    status.textContent = 'Creating your 3D model… This can take a little while.';

    // The browser cannot know the worker's exact percentage, so this is an
    // honest stage-based progress indicator rather than pretending to have
    // server-side progress telemetry.
    const progressTimer = setInterval(() => {
      const current = parseInt(progressPercent?.textContent || '25', 10) || 25;
      if (current < 68) {
        const next = Math.min(68, current + 1);
        setProgress(next, 'Creating your 3D model…', 'AI reconstruction is still running. Please keep this page open.');
      }
    }, 1200);

    let response;
    try {
      response = await fetch('/api/generate-3d', {
        method: 'POST',
        body: data,
        headers: {
          'x-edulabs-subject': subjectInput?.value || 'general',
          'x-edulabs-topic': topicInput?.value?.trim() || ''
        }
      });
    } finally {
      clearInterval(progressTimer);
    }

    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.message || result.error || `3D service returned ${response.status}`);

    const modelUrl = result.modelUrl || result.glbUrl || result.outputUrl || result.url || result.model?.url;
    if (!modelUrl) throw new Error(result.error || 'The 3D service returned no model file.');

    generatedModelUrl = modelUrl;
    setStep('fix');
    setProgress(78, 'Setting up your 3D model…', 'Centering, scaling, and orienting the model for the viewer.');
    status.textContent = 'Centering and orienting the 3D model…';

    window.loadScienceModel(modelUrl);

    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('The model took too long to load.')), 30000);
      const done = () => { clearTimeout(timeout); window.removeEventListener('science-model-rendered', done); window.removeEventListener('science-model-error', failed); resolve(); };
      const failed = event => { clearTimeout(timeout); window.removeEventListener('science-model-rendered', done); window.removeEventListener('science-model-error', failed); reject(event.detail || new Error('3D viewer failed')); };
      window.addEventListener('science-model-rendered', done, { once: true });
      window.addEventListener('science-model-error', failed, { once: true });
    });

    setStep('ready');
    setProgress(100, '3D model ready!', 'Your model is loaded. Drag to rotate and scroll to zoom.', false);
    if (downloadButton) {
      downloadButton.href = modelUrl;
      downloadButton.hidden = false;
    }
    status.textContent = 'Your 3D science model is ready. Drag it to rotate and scroll to zoom.';
  } catch (error) {
    console.error('EduLabs 3D generation failed:', error);
    setStep('prepare');
    setProgress(0, '3D generation stopped', friendlyError(error), false);
    status.textContent = friendlyError(error);
  } finally {
    threeButton.disabled = false;
    threeButton.classList.remove('generate-busy');
    threeButton.textContent = originalButtonText;
  }
}

window.addEventListener('load', () => {
  if (status) status.textContent = '🟢 EduLabs 3D Lab Ready. Upload a science image to begin.';
  const octopus = document.getElementById('octopusStatus');
  if (octopus) octopus.textContent = '🐙 I am ready to help explain your science model.';
});

const regenerateLessonButton = document.getElementById('regenerateLesson');
regenerateLessonButton?.addEventListener('click', async () => {
  const prompt = document.getElementById('lessonPrompt')?.value || '';
  const octopus = document.getElementById('octopusStatus');
  if (octopus) octopus.textContent = '🐙 Updating your educational lesson...';
  try {
    const response = await fetch('/api/generate-lesson', {
      method:'POST',
      headers:{'content-type':'application/json'},
      body:JSON.stringify({subject: subjectInput?.value || 'science', prompt})
    });
    const data = await response.json();
    if (octopus) octopus.textContent = '🐙 Lesson updated: ' + (data.lesson?.requestedChanges || 'ready');
  } catch(e) {
    if (octopus) octopus.textContent = '🐙 I could not update the lesson yet.';
  }
});

threeButton?.addEventListener('click', generateReal3D);
